#ifndef EAX_GLOBALS_INCLUDED
#define EAX_GLOBALS_INCLUDED

inline bool eax_g_is_enabled{true};

#endif /* EAX_GLOBALS_INCLUDED */
