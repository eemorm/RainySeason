
#include "config.h"

#include "except.h"


namespace al {

base_exception::~base_exception() = default;

} // namespace al
